<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap wrap-home-wide2 cf errorpage">

					<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
						
				<article id="post-not-found" class="search-not-found hentry cf">
					<header class="article-header">
						<h1><?php _e( 'Sorry!', 'bonestheme' ); ?></h1>
						<h2><?php _e( 'We could not find a result for you.', 'bonestheme' ); ?></h2>
					</header>
					<section class="entry-content">
						<p><?php _e( 'Looking for something? Try searching again!', 'bonestheme' ); ?><br/>Or go to our <a href="<?php echo home_url(); ?>" rel="nofollow">Homepage</a> for more</p>
					</section>
					
					
											
				</article>

				<form role="search" method="get" id="searchform2" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput2" class="sb-search-input" placeholder="Can't find something? Search again" type="text" value="" name="s" id="s">
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>

					</main>

				</div>

			</div>

<?php get_footer(); ?>
