<!doctype html>


<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

	<head>
		<meta charset="utf-8">

		<?php // force Internet Explorer to use the latest rendering engine available ?>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta property='fb:app_id' content='1879518042374338' />
		<?php
		if ( is_front_page() ) { ?>
    <title><?php echo get_bloginfo( 'name' ); ?> | <?php echo get_bloginfo( 'description' ); ?></title>
    
	<?php } else if (is_single() )  { ?>
	  		  <title><?php wp_title(''); ?> | <?php echo get_bloginfo( 'name' ); ?></title>
    <?php } else { ?>
    <title><?php wp_title(''); ?> | <?php echo get_bloginfo( 'name' ); ?> - <?php echo get_bloginfo( 'description' ); ?></title>

<?php }  ?>

		<?php // mobile meta (hooray!) ?>
		<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densityDpi=device-dpi"/>

		<?php // icons & favicons (for more: http://www.jonathantneal.com/blog/understand-the-favicon/) ?>
		<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/library/images/apple-touch-icon.png">
		<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
		<!--[if IE]>
			<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
		<![endif]-->
		<?php // or, set /favicon.ico for IE10 win ?>
		<meta name="msapplication-TileColor" content="#f01d4f">
		<meta name="msapplication-TileImage" content="<?php echo get_template_directory_uri(); ?>/library/images/win8-tile-icon.png">
            <meta name="theme-color" content="#121212"> 

		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
		
		<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/library/css/font-awesome-4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,600" rel="stylesheet">

		<!-- Scroll Animation Tweening -->
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/library/js/scrollmagic/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/library/js/scrollmagic/greensock/TweenMax.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/library/js/scrollmagic/minified/ScrollMagic.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/library/js/scrollmagic/minified/plugins/animation.gsap.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/library/js/scrollmagic/minified/plugins/debug.addIndicators.min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/jquery.countdown.min.js"></script>
		<!-- addIndicators for visual debugging -->
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/chartist.min.js"></script>
		
	
		
		<?php // wordpress head functions ?>
		<?php wp_head(); ?>
		<?php // end of wordpress head ?>
		
		
		
		<?php // drop Google Analytics Here ?>
		<?php // end analytics ?>

	</head>

	<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">
		
		 
		<div id="container">

				<?php include('template-header2.php');?>
