<?php
/*
 Template Name: Get Tokens
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	$headertitle = get_post_meta($post->ID, 'wpcf-tokens-header-title', true);
		$headertext = get_post_meta($post->ID, 'wpcf-tokens-header-text', true);
?>


	<?php get_header(); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content">
			
			<section class="home-top home-top-2">
					
					<div class="home-top-container home-top-container-small">
							      
							  <video id="vidhero" muted loop preload="auto" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-bg-std3.jpg" id="bgvid">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-banner.mp4" type="video/mp4">
			</video>
						
							  <div class="video-overlay video-overlay-small">
								
								  <?php echo apply_filters('the_content',$headertitle); ?>
								  
								  <?php echo apply_filters('the_content',$headertext); ?>
								  
								 
							  </div>
					
					
					</div>
				</section>
				
				<section class="home-1 home-1-alt">
					
				
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-4of7 cf">
							
								<div class="sale-box sale-box-alt">
								
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$saletype = get_post_meta($post->ID, 'wpcf-sale-type', true);
							$saledeadline = get_post_meta($post->ID, 'wpcf-sale-deadline', true);
							$salemilestone = get_post_meta($post->ID, 'wpcf-sale-milestone', true);
							$saleprogress = get_post_meta($post->ID, 'wpcf-sale-progress', true);
							$salebonus = get_post_meta($post->ID, 'wpcf-current-bonus', true);
							$salecomm = get_post_meta($post->ID, 'wpcf-min-commitment', true);
							$salegas = get_post_meta($post->ID, 'wpcf-gas-limit', true);
							$bonusexp = get_post_meta($post->ID, 'wpcf-bonus-expiry', true);
							$salecta = get_post_meta($post->ID, 'wpcf-sale-cta', true);
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							$walletform = get_post_meta($post->ID, 'wpcf-wallet-form', true);
							
							$friendly_date = date_i18n( 'Y/m/d H:i:s', $saledeadline );
							$friendly_date2 = date_i18n( 'Y/m/d H:i:s', $bonusexp );

							$salevalue = $saleprogress / $salemilestone;
							
							$salepercent = round((float)$salevalue * 100 ) . '%';

							
							  setup_postdata( $post ); ?> 
							  
							  <h2 class="live-alert">Token Sale is <strong>Live</strong></h2>
								<h3>Ends In <span id="clock"></span></h3> 
									
									<script type="text/javascript">
									  // 15 days from now!
									  $('#clock').countdown('<?php echo $friendly_date; ?>', function(event) {
									    $(this).html(event.strftime('%DD %HH %MM %SS'));
									  });
									</script>
								<hr>
								
								<div class="sale-bar-container">
									
									
									
									<div id="progressbar">
										<div class="tokensale">
										<h3>Token Sale Progress</h3>
										</div>
										<div class="milestone">
											<h4>Milestone</h4>
											<p><span class="countmilestone"><?php echo $salemilestone;?></span> USD</p>
										</div>
									
										<div class="progressbg"><span class="progress"></span></div>
										
										<div class="actuals">
											<div class="arrow-up"></div>
											<p><span class="count"><?php echo $saleprogress;?></span> USD</p>
											<h4>Contributed</h4>
										</div>
									</div>
									
								</div>
							
							<div class="sale-box-field sale-box-field-2 sale-box-field-first">
								<label>Current Bonus</label>
								 <?php echo apply_filters('the_content',$salebonus); ?>
							</div>
							
							<div class="sale-box-field sale-box-field-2">
								<label>Bonus Expiring In</label>
								 <p id="clock2"></p>
								 <script type="text/javascript">
									  // 15 days from now!
									  $('#clock2').countdown('<?php echo $friendly_date2; ?>', function(event) {
									    $(this).html(event.strftime('%DD %HH %MM %SS'));
									  });
									</script>
							</div>
							<div class="sale-box-field sale-box-field-2">
								<label>Min. Commitment</label>
								 <?php echo apply_filters('the_content',$salecomm); ?>
							</div>
							<div class="sale-box-field sale-box-field-2">
								<label>Gas Limit</label>
								 <?php echo apply_filters('the_content',$salegas); ?>
							</div>
							
							<div class="sale-box-field sale-box-cta-2 sale-box-field-last">
								  <?php echo apply_filters('the_content',$walletform); ?>
								 
								
							</div>
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
								
							</div>
							
							
					
						</div>
						
						
						<div class="m-all t-all d-3of7 last-col cf">
			
							
							<div class="sale-box sale-box-alt sale-box-alt-3">
								
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-details' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
						
							  setup_postdata( $post ); ?> 
							  
							  
							
						
							<div class="sale-box-field sale-box-cta-2 sale-box-field-last">
								  <?php the_content(); ?>
								 
								
							</div>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
								
							</div>
							
							
								<div class="sale-box sale-box-alt sale-box-alt-2">
								
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
						
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							$walletform = get_post_meta($post->ID, 'wpcf-wallet-form', true);
							  setup_postdata( $post ); ?> 
							  
							  
							
						
							<div class="sale-box-field sale-box-cta-2 sale-box-cta-3 sale-box-field-last">
								  <?php echo apply_filters('the_content',$notified); ?>
								 
								
							</div>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
								
							</div>
							
							
						
							
							
						</div>
					</div>
					
					
					
				
				</section>
				
				
				
						
				<section class="home-3" id="tokensale">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							
										
									<h2>Initial Token Sale</h2>
									
										<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'token-sale' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$ts1 = get_post_meta($post->ID, 'wpcf-token-sale-1', true);
							$ts2 = get_post_meta($post->ID, 'wpcf-token-sale-2', true);
							$ts3 = get_post_meta($post->ID, 'wpcf-token-sale-3', true);
							
							  setup_postdata( $post ); ?> 
							  
							  
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									 
								<ul class="progress">	
								<li data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								
								
								<!--  Defining Angle Gradient Colors  -->
									<svg width="0" height="0">
									<defs>
									<linearGradient id="cl1" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="1" y2="1">
									    <stop stop-color="#ce1f78"/>
									    <stop offset="100%" stop-color="#a63895"/>
									</linearGradient>
									<linearGradient id="cl2" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="0" y2="1">
									    <stop stop-color="#a63895"/>
									    <stop offset="100%" stop-color="#3e79e0"/>
									</linearGradient>
									<linearGradient id="cl3" gradientUnits="objectBoundingBox" x1="1" y1="0" x2="0" y2="1">
									    <stop stop-color="#3e79e0"/>
									    <stop offset="100%" stop-color="#506dd3"/>
									</linearGradient>
									<linearGradient id="cl4" gradientUnits="objectBoundingBox" x1="1" y1="1" x2="0" y2="0">
									    <stop stop-color="#506dd3"/>
									    <stop offset="100%" stop-color="#b42f8b"/>
									</linearGradient>
									<linearGradient id="cl5" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="0" y2="0">
									    <stop stop-color="#b42f8b"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									<linearGradient id="cl6" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="1" y2="0">
									    <stop stop-color="#d41b74"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									</defs>
									</svg>
									
									
								  <?php echo apply_filters('the_content',$ts1); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="second" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								 <?php echo apply_filters('the_content',$ts2); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 last-col cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="third" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								<?php echo apply_filters('the_content',$ts3); ?>
								</div>
							</div>
							
							<div class="m-all t-all d-all cf">
								<a href="<?php echo home_url(); ?>/get-megax-tokens" rel="nofollow"> <button class="gettoken">Get MegaX Tokens</button></a>
								
							</div>
								 
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
						
							<div class="m-all t-all d-all cf roadmap-container">
							
								<h2>12-Month Product Roadmap</h2>
							
								<div class="roadmap-mobile">
									
									
									<div class="entries">
								  <div class="entry">
									    <div class="title big">2014-2017</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="body">
									      <p>Acquisition of 4 Retail Brands & Marketplaces</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
								    <div class="title big">2017</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">January</div>
									    <div class="body">
									      <p>Collaboration with MC Payments on Blockchain</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">August</div>
									    <div class="body">
									      <p>Blockchain Complete</p>
									    </div>
									</div>
								  </div>
								  <div class="entry current-entry">
									<div class="entry-container">
									    <div class="title">October</div>
									    <div class="body">
									      <p>Initial Token Sale</p>
									    </div>
									 </div>
								  </div>
								  <div class="entry">
								    <div class="entry-container">
									    <div class="title">Q4</div>
									    <div class="body">
									      <p>MEGAX Mall + Android Wallet</p>
									    </div>
									 </div>
								  </div>
								  <div class="entry">
								    <div class="title big">2018</div>
								  </div>
								  <div class="entry">
									  <div class="entry-container">
									    <div class="title">Q1</div>
									    <div class="body">
									      <p>iOS App Wallet</p>
									    </div>
									  </div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">Q2</div>
									    <div class="body">
									      <p>Launch of MEGAX Token physical NFC Wallet</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">Q3</div>
									    <div class="body">
									      <p>Launch of MEGAX Mobile POS Retailer Hardware for Android</p>
									    </div>
									</div>
								  </div>
								</div>
     
								
								
								
								</div>
								
								<div class="roadmap-desktop">
									<?php
								
								$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'roadmap-desktop' );
								$postslist = get_posts( $args );
								foreach ( $postslist as $post ) :
								setup_postdata( $post ); ?> 
								  
								  
								  <?php the_content(); ?>
								  
								<?php endforeach; wp_reset_postdata(); ?>	
								</div>
								
								
							
							
								
							
							</div>
							
					</div>
				</section>
			
			
			
			
				
					
				</div>



	
		<script type="text/javascript">



function numberWithCommas(number) {
    var parts = number.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}


$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
            var num = $(this).text();
		    var commaNum = numberWithCommas(num);
		    $(this).text(commaNum);
		 }
    });
});

$(".countmilestone").each(function() {
    var num = $(this).text();
    var commaNum = numberWithCommas(num);
    $(this).text(commaNum);
  });


var percent = <?php echo $salevalue; ?>;
var percentage = "<?php echo $salepercent; ?>";

if (percent <= 0.3) {
	$(".progress").animate({
    width: percentage,
    opacity: 1
	});
	
	$(".actuals").animate({
	    opacity: 1,
	    
	});
	$(".actuals").addClass('left');
	
} else {
	
	$(".progress").animate({
    width: percentage,
    opacity: 1
	});
	
	$(".actuals").animate({
	    marginLeft: percentage,
	    opacity: 1
	});

}




// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	
	var vidHero = document.getElementById('vidhero');
	var $vh = $('#vidhero');

	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
				var scene5 = new ScrollMagic.Scene({triggerElement: "#vidhero", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 vidHero.play();
				
					})
				
	

	</script>

									

<?php get_footer(); ?>
