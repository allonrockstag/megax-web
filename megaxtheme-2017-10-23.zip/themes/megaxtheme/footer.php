			
	
		<footer class="footer" id="footer" role="contentinfo">
			
				<div class="footer-top">
					<div id="inner-footer" class="wrap cf">
						
							<h3>Social</h3>
						<ul class="footer-social">
								<li class="footer-icon"><a href="https://www.facebook.com/megaxcoin/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/megaXcoin"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.instagram.com/megaxcoin/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://medium.com/@megaXcoin"><i class="fa fa-medium" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://t.me/Megaxcoin"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
							</ul>
							
					</div>
				</div>
				
				
				<div class="footer-middle">
					<div id="inner-footer" class="wrap wrap-small cf">
					
					<div class="m-all t-all d-all cf">
					
					<div class="footer-logo">
						<a href="<?php echo get_home_url(); ?>"><img src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-logo-box2.png" /></a>
					</div>               	
					
					</div>
		
					
					<div class="m-all t-1of3 d-1of3 cf">
							<h4>Company</h4>
								
						 <nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav cf',
						'menu' 			=> 'FooterNav2' 
						
						)); ?>
						</nav>
						
						
						   
					</div>
					
					<div class="m-all t-1of3 d-1of3 cf footer-nav-container">
						
						<h4>MegaX</h4>
					 
						<nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu(array(
    					'menu' => __( 'FooterNav', 'bonestheme' ),   // nav name
    					'menu_class' => 'footer-nav cf',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
						</nav>  
						</div>


					<div class="m-all t-1of3 d-1of3 last-col footer-contact">
						
						<h4>Affiliate Programme</h4>
						
						 <nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav footer-nav-ref cf',
						'menu' 			=> 'FooterNav3' 
						
						)); ?>
						</nav>
					
							
						              	
					
					</div>
					

					</div>
					
				</div>
				
				
				<div id="inner-footer" class="wrap cf footer-end">
				<div class="m-all t-all d-all cf">
					<p class="source-org copyright">&copy; <?php echo date('Y'); ?> iFashion Group Pte Ltd. All Rights Reserved.&nbsp;&nbsp;<a href="<?php echo get_home_url(); ?>/privacy-policy">Privacy Policy</a>&nbsp;&nbsp;<a href="<?php echo get_home_url(); ?>/terms-of-use">Terms of Service</a></p>
				</div>
				</div>

			</footer>

		</div>
		
		
		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/classie.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/fluidvids.min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/flickity.pkgd.min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/jquery.scrollme.js"></script>
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/featherlight.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="https://code.jquery.com/jquery-2.2.4.min.js"
			  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
			  crossorigin="anonymous"></script>
		<?php include('jscript-main.php');?>
			  
		
	
	
	</body>

</html> <!-- end of site. what a ride! -->
