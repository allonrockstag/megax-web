<?php
/*
Template Name: Contact
*/
?>

<?php get_header(); ?>

		

			<div id="content">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							
							
<?php 
	$contactform = get_post_meta($post->ID, 'wpcf-contact-form', true);
	$contactoffice = get_post_meta($post->ID, 'wpcf-contact-office', true);
	$contact1 = get_post_meta($post->ID, 'wpcf-contact-1', true);
	$contact2 = get_post_meta($post->ID, 'wpcf-contact-2', true);
	$contact3 = get_post_meta($post->ID, 'wpcf-contact-3', true);
	$contact4 = get_post_meta($post->ID, 'wpcf-contact-4', true);
?>

							
							
			<div class="standard-header">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
						<h1 class="page-title page-title-2" itemprop="headline"><?php the_title(); ?></h1>
						</div>
					</div>
				</div>
			
			<section class="contact-1">
			<div id="inner-content" class="wrap wrap-home-wide cf">
			
				<div class="m-all t-all d-1of2 cf contact-1-left">
					<h2>Leave Us A Message</h2>
					<?php echo apply_filters('the_content',$contactform); ?>
				</div>
				<div class="m-all t-all d-1of2 last-col cf contact-1-right">
					<h2>Have a Chat at Our Office</h2>
					
					<div class="m-all t-1of2 d-all cf contact-1-right-container">
						<div class="m-all t-all d-1of3 cf">
							<h3>Singapore</h3>
						</div>
						<div class="m-all t-all d-2of3	 last-col cf">
							<?php echo apply_filters('the_content',$contactoffice); ?>
						</div>
					</div>
					<!--<div class="m-all t-1of2 d-all cf contact-1-right-container">
						<div class="m-all t-all d-1of3 cf">
							<h3>???</h3>
						</div>
						<div class="m-all t-all d-2of3 last-col cf">
							<?php echo apply_filters('the_content',$contactoffice2); ?>
						</div>
					</div>
					-->
					
				</div>
			</div>
			</section>
			
		<!--	<section class="contact-2">
				<div id="inner-content" class="wrap wrap-home-wide cf">
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact1); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact2); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 cf contact-2-list">
						<?php echo apply_filters('the_content',$contact3); ?>
					</div>
					<div class="m-all t-1of2 d-1of4 last-col cf contact-2-list">
						<?php echo apply_filters('the_content',$contact4); ?>
					</div>
				</div>
			</section>
			-->
	
				
		
													
			<!--<div id="inner-content" class="wrap wrap-home-wide cf">

						<main id="main" class="m-all t-all d-all cf standard-body " role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
				
				


							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									
								</header> <?php // end article header ?>

								<section class="entry-content entry-content-small cf" itemprop="articleBody">
								
									
									<?php the_content(); ?>
									
									
								</section> <?php // end article section ?>

								

							</article>

							<?php endwhile; ?>
							<?php else : ?>
							<?php endif; ?>
								
						</main>


				</div>-->
				

			</div>
			
			
		
		


<?php get_footer(); ?>

