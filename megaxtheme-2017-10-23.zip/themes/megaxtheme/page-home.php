<?php
/*
 Template Name: Home
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	
		$ytid = get_post_meta($post->ID, 'wpcf-youtube-video-url', true);
		$htitle = get_post_meta($post->ID, 'wpcf-hero-title', true);
		$htext = get_post_meta($post->ID, 'wpcf-hero-text', true);
		$f1 = get_post_meta($post->ID, 'wpcf-feature-1', true);
		$f2 = get_post_meta($post->ID, 'wpcf-feature-2', true);
		$f3 = get_post_meta($post->ID, 'wpcf-feature-3', true);
		$sf1 = get_post_meta($post->ID, 'wpcf-sub-feature-1', true);
		$sf2 = get_post_meta($post->ID, 'wpcf-sub-feature-2', true);
		$sf3 = get_post_meta($post->ID, 'wpcf-sub-feature-3', true);
		$sfi1 = get_post_meta($post->ID, 'wpcf-sub-feature-img-1', true);
		$sfi2 = get_post_meta($post->ID, 'wpcf-sub-feature-img-2', true);
		$sfi3 = get_post_meta($post->ID, 'wpcf-sub-feature-img-3', true);
		
		// GET YOUTUBE ID
		$link = $ytid;
		$video_id = explode("?v=", $link); // For videos like http://www.youtube.com/watch?v=...
		if (empty($video_id[1]))
		    $video_id = explode("/v/", $link); // For videos like http://www.youtube.com/watch/v/..
		
		$video_id = explode("&", $video_id[1]); // Deleting any other params
		$video_id = $video_id[0];

?>


	<?php get_header('header2'); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content">
				


				<section class="home-top collapsed">
					
					<div class="home-top-container scrollme animateme"
						      data-when="exit"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-opacity="0.3">
							      
							<div class="herobg-mobile">
								 <div class="video-overlay">
								  <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0.3"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-opacity="0.2"
						data-translatey="50"
						data-scale="0.9">
								  <?php echo apply_filters('the_content',$htitle); ?>
							
								  </div>
								  
							<a href="https://www.youtube.com/embed/<?php echo $video_id ?>" data-featherlight="iframe" data-featherlight-iframe-min-height="300"><button class="play2">Watch the Film</button></a>

								
								<?php echo apply_filters('the_content',$htext); ?>
								   
							  </div>
								
							</div>
							<div class="herobg-desktop">
							      <div id="ytplayer"></div>
							      
							   

							       <script async src="https://www.youtube.com/iframe_api"></script>
									<script>
										
										function onYouTubeIframeAPIReady() {
										  var player;
										  var vidid = '<?php echo $video_id ?>';
										  
										  player = new YT.Player('ytplayer', {
										    videoId: vidid, // YouTube Video ID
										    width: 640,               // Player width (in px)
										    height: 360,              // Player height (in px)
										    playerVars: {
										      autoplay: 1,        // Auto-play the video on load
										      controls: 0,        // Show pause/play buttons in player
										      showinfo: 0,        // Hide the video title
										      rel: 0,
										      loop: 1,
										      playlist: vidid,
										      modestbranding: 1,  // Hide the Youtube Logo
										      fs: 1,              // Hide the full screen button
										      cc_load_policy: 1, // Hide closed captions
										      iv_load_policy: 3,  // Hide the Video Annotations
										      autohide: 1	// Hide video controls when playing
										            
										    },
										    events: {
										      onReady: function(e) {
										        e.target.mute();
										        e.target.setVolume(70);
										        
										        var playButton = document.getElementById("play");
										        playButton.addEventListener("click", function() {
											    	player.unMute();
												});
												
												var closeButton = document.getElementById("closevideo");
												closeButton.addEventListener("click", function() {
											    	player.mute();
												});
											  
										      }
										    }
										    
										    
										  });
										  
										 }
									</script>

					
						
						
							<div class="video-overlay-2">
								
								<button id="closevideo" class="closevideo">Close</button>
							</div>
							  <div class="video-overlay">
								  <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0.3"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-opacity="0.2"
						data-translatey="50"
						data-scale="0.9">
								  <?php echo apply_filters('the_content',$htitle); ?>
							
								  </div>
								  
								  <div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0.3"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-opacity="0.2"
						data-translatey="30"
						data-scale="0.9">
								<button id="play" class="play">Watch the Film</button>
								 </div>
								 
								<div class="home-title scrollme animateme"
						data-when="exit"
					    data-from="0.3"
					    data-to="1"
					    data-easing="linear"
						data-crop="true"
							data-opacity="0.2"
						data-translatey="30"
						data-scale="0.9">
							
								   <?php echo apply_filters('the_content',$htext); ?>
								</div>
							  </div>
					
							</div>
					
					</div>
				</section>
				
				<section class="home-1">
					
				
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-1of2 d-1of2 cf home-1-left">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.5"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="30">
							
				<h1>MegaX</h1>
				</div>
				
				
				<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.5"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="50"
						>
						<?php the_content(); ?>
					</div>
				
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
						
						
						<div class="m-all t-1of2 d-1of2 last-col cf">
							<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.5"
								    data-to="0.0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="30">
							<div class="sale-box">
								
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$salestatus = get_post_meta($post->ID, 'wpcf-sale-status', true);
							$saledeadline = get_post_meta($post->ID, 'wpcf-sale-deadline', true);
							$salemilestone = get_post_meta($post->ID, 'wpcf-sale-milestone', true);
							$saleprogress = get_post_meta($post->ID, 'wpcf-sale-progress', true);
							$salebonus = get_post_meta($post->ID, 'wpcf-current-bonus', true);
							$salecomm = get_post_meta($post->ID, 'wpcf-min-commitment', true);
							$salegas = get_post_meta($post->ID, 'wpcf-gas-limit', true);
							$bonusexp = get_post_meta($post->ID, 'wpcf-bonus-expiry', true);
							$salecta = get_post_meta($post->ID, 'wpcf-sale-cta', true);
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							
							
							$friendly_date = date_i18n( 'Y/m/d H:i:s', $saledeadline );
							$friendly_date2 = date_i18n( 'Y/m/d H:i:s', $bonusexp );

							$salevalue = $saleprogress / $salemilestone;
							
							$salepercent = round((float)$salevalue * 100 ) . '%';

							  setup_postdata( $post ); ?> 
							  
							  
							  <?php if ($salestatus == 1) { ?>
								<h2 class="live-alert">Token Sale is <strong>Live</strong></h2>
								<h3>Ends In <span id="clock"></span></h3> 
								<?php the_content(); ?>	
									
								<script type="text/javascript">
								  // 15 days from now!
								  $('#clock').countdown('<?php echo $friendly_date; ?>', function(event) {
								    $(this).html(event.strftime('%DD %HH %MM %SS'));
								  });
								</script>
									
							 <?php } else if ($salestatus == 3) {  ?>
								  <h2 class="live-alert">Token Pre-sale is <strong>Live</strong></h2>
								  <h3>Ends In <span id="clock"></span></h3> 
								<?php the_content(); ?>	
									
								<script type="text/javascript">
								  // 15 days from now!
								  $('#clock').countdown('<?php echo $friendly_date; ?>', function(event) {
								    $(this).html(event.strftime('%DD %HH %MM %SS'));
								  });
								</script>
							  <?php } else if ($salestatus == 2) {  ?>
								  <h2>Token Sale has Ended</strong></h2>
								  
								  <?php the_content(); ?>	
								  
							  <?php } ?>
							  
							  
							 
								<hr>
								
								<div class="sale-bar-container">
									
									
									
									<div id="progressbar">
										<div class="tokensale">
										<h3>Token Sale Progress</h3>
										</div>
										<div class="milestone">
											<h4>Milestone</h4>
											<p><span class="countmilestone"><?php echo $salemilestone;?></span> USD</p>
										</div>
									
										<div class="progressbg"><span class="progress"></span></div>
										
										<div class="actuals">
											<div class="arrow-up"></div>
											<p><span class="count"><?php echo $saleprogress;?></span> USD</p>
											<h4>Contributed</h4>
										</div>
									</div>
									
								</div>
							
							<div class="sale-box-field sale-box-field-first">
								<label>Current Bonus</label>
								 <?php echo apply_filters('the_content',$salebonus); ?>
							</div>
							
							<div class="sale-box-field">
								<label>Bonus Expiring In</label>
								 <p id="clock2"></p>
								 <script type="text/javascript">
									  // 15 days from now!
									  $('#clock2').countdown('<?php echo $friendly_date2; ?>', function(event) {
									    $(this).html(event.strftime('%DD %HH %MM %SS'));
									  });
									</script>
							</div>
							<div class="sale-box-field">
								<label>Min. Commitment</label>
								 <?php echo apply_filters('the_content',$salecomm); ?>
							</div>
							<div class="sale-box-field">
								<label>Gas Limit</label>
								 <?php echo apply_filters('the_content',$salegas); ?>
							</div>
							
							
							<div class="sale-box-field sale-box-cta sale-box-field-last">
								 <?php echo apply_filters('the_content',$salecta); ?>
								 
								<a href="<?php echo home_url(); ?>/get-megax-tokens" rel="nofollow"><button>Get MegaX Tokens</button></a>
							</div>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
								
							</div>
							
							</div>
							
							
							<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.2"
								    data-to="0.0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="20">
							<div class="sale-box sale-box-2">
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$saletype = get_post_meta($post->ID, 'wpcf-sale-type', true);
							$saledeadline = get_post_meta($post->ID, 'wpcf-sale-deadline', true);
							$salemilestone = get_post_meta($post->ID, 'wpcf-sale-milestone', true);
							$saleprogress = get_post_meta($post->ID, 'wpcf-sale-progress', true);
							$salebonus = get_post_meta($post->ID, 'wpcf-sale-bonus', true);
							$salecomm = get_post_meta($post->ID, 'wpcf-sale-commitment', true);
							$salegas = get_post_meta($post->ID, 'wpcf-gas-limit', true);
							$bonusexp = get_post_meta($post->ID, 'wpcf-bonus-expiry', true);
							$salecta = get_post_meta($post->ID, 'wpcf-sale-cta', true);
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							
							  setup_postdata( $post ); ?> 
							  
							  
							
								  <?php echo apply_filters('the_content',$notified); ?>
								 
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							</div>
							
							</div>
						</div>
					</div>
					
			
			
					
				</section>
				
				<section class="home-1a" id="features">
					<div class="home-feature">
						
							<div id="feature1" class="feature-video feature-video-1 scrollme animateme scrollmedesktop"
							      data-when="span"
							      data-from="0"
							      data-to="1"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="400">
								      
								       <video id="vidfeature1" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-currencies.jpg" muted preload="auto">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-currencies.mp4" type="video/mp4">
			</video>
			
			
							      </div>
							
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist1"></div>
							<ul class="home-svc-list">
								<li id="animatelist1"><?php echo apply_filters('the_content',$f1); ?>
								<a href="#feature2"><span class="nextbutton"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
								</li>
								
							</ul>
							
							</div>
						</div>
					</div>
					<div class="home-feature">
						
					<div id="feature2" class="feature-video feature-video-2 scrollme animateme"
							      data-when="span"
							      data-from="0"
							      data-to="1"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="350">
								      <video id="vidfeature2" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-event.jpg" muted loop preload="auto">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-event.mp4" type="video/mp4">
			</video>
			
							      </div>
						
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist2"></div>
							<ul class="home-svc-list">
								<li id="animatelist2"><?php echo apply_filters('the_content',$f2); ?>
								<a href="#feature3"><span class="nextbutton"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
								</li>
								
							</ul>
							
							</div>
						</div>
					</div>
					<div class="home-feature">
						
					<div id="feature3" class="feature-video feature-video-3 scrollme animateme"
							      data-when="span"
							      data-from="0"
							      data-to="1"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="300">
								       <video id="vidfeature3" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-coin.jpg" muted preload="auto">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-coin.mp4" type="video/mp4">
			</video>
							      </div>
						
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist3"></div>
							<ul class="home-svc-list">
								<li id="animatelist3"><?php echo apply_filters('the_content',$f3); ?>
								<a href="#featuresub"><span class="nextbutton"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
								</li>
								
							</ul>
							
							
							</div>
						</div>
					</div>
					
					
					<div id="featuresub" class="home-subfeature">
						<div id="inner-content" class="wrap cf">
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="subfeature-list">
								<div class="subfeature-img" style="background-image:url(<?php echo $sfi1; ?>);"></div>
								<?php echo apply_filters('the_content',$sf1); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="subfeature-list">
									<div class="subfeature-img" style="background-image:url(<?php echo $sfi2; ?>);"></div>
								<?php echo apply_filters('the_content',$sf2); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 last-col cf">
								<div class="subfeature-list">
									<div class="subfeature-img" style="background-image:url(<?php echo $sfi3; ?>);"></div>
								<?php echo apply_filters('the_content',$sf3); ?>
								</div>
							</div>
							
						</div>
					</div>
				</section>
					
					
						
						
				<section class="home-3" id="tokensale">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							
										
									<h2>Initial Token Sale</h2>
									
										<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'token-sale' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$ts1 = get_post_meta($post->ID, 'wpcf-token-sale-1', true);
							$ts2 = get_post_meta($post->ID, 'wpcf-token-sale-2', true);
							$ts3 = get_post_meta($post->ID, 'wpcf-token-sale-3', true);
							
							  setup_postdata( $post ); ?> 
							  
							  
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									 
								<ul class="progress">	
								<li data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								
								
								<!--  Defining Angle Gradient Colors  -->
									<svg width="0" height="0">
									<defs>
									<linearGradient id="cl1" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="1" y2="1">
									    <stop stop-color="#ce1f78"/>
									    <stop offset="100%" stop-color="#a63895"/>
									</linearGradient>
									<linearGradient id="cl2" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="0" y2="1">
									    <stop stop-color="#a63895"/>
									    <stop offset="100%" stop-color="#3e79e0"/>
									</linearGradient>
									<linearGradient id="cl3" gradientUnits="objectBoundingBox" x1="1" y1="0" x2="0" y2="1">
									    <stop stop-color="#3e79e0"/>
									    <stop offset="100%" stop-color="#506dd3"/>
									</linearGradient>
									<linearGradient id="cl4" gradientUnits="objectBoundingBox" x1="1" y1="1" x2="0" y2="0">
									    <stop stop-color="#506dd3"/>
									    <stop offset="100%" stop-color="#b42f8b"/>
									</linearGradient>
									<linearGradient id="cl5" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="0" y2="0">
									    <stop stop-color="#b42f8b"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									<linearGradient id="cl6" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="1" y2="0">
									    <stop stop-color="#d41b74"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									</defs>
									</svg>
									
									
								  <?php echo apply_filters('the_content',$ts1); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="second" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								 <?php echo apply_filters('the_content',$ts2); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 last-col cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="third" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								<?php echo apply_filters('the_content',$ts3); ?>
								</div>
							</div>
							
							<div class="m-all t-all d-all cf">
								<a href="<?php echo home_url(); ?>/get-megax-tokens" rel="nofollow"> <button class="gettoken">Get MegaX Tokens</button></a>
								
							</div>
								 
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
						
							<div class="m-all t-all d-all cf roadmap-container">
							
								<h2>12-Month Product Roadmap</h2>
							
								<div class="roadmap-mobile">
									
									
									<div class="entries">
								  <div class="entry">
									    <div class="title big">2014-2017</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="body">
									      <p>Acquisition of 4 Retail Brands & Marketplaces</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
								    <div class="title big">2017</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">January</div>
									    <div class="body">
									      <p>Collaboration with MC Payment on Blockchain</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">August</div>
									    <div class="body">
									      <p>Blockchain Complete</p>
									    </div>
									</div>
								  </div>
								  <div class="entry current-entry">
									<div class="entry-container">
									    <div class="title">October</div>
									    <div class="body">
									      <p>Initial Token Sale</p>
									    </div>
									 </div>
								  </div>
								  <div class="entry">
								    <div class="entry-container">
									    <div class="title">Q4</div>
									    <div class="body">
									      <p>MEGAX Mall + Android Wallet</p>
									    </div>
									 </div>
								  </div>
								  <div class="entry">
								    <div class="title big">2018</div>
								  </div>
								  <div class="entry">
									  <div class="entry-container">
									    <div class="title">Q1</div>
									    <div class="body">
									      <p>iOS App Wallet</p>
									    </div>
									  </div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">Q2</div>
									    <div class="body">
									      <p>Launch of MEGAX Token physical NFC Wallet</p>
									    </div>
									</div>
								  </div>
								  <div class="entry">
									<div class="entry-container">
									    <div class="title">Q3</div>
									    <div class="body">
									      <p>Launch of MEGAX Mobile POS Retailer Hardware for Android</p>
									    </div>
									</div>
								  </div>
								</div>
     
								
								
								
								</div>
								
								<div class="roadmap-desktop">
									<?php
								
								$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'roadmap-desktop' );
								$postslist = get_posts( $args );
								foreach ( $postslist as $post ) :
								setup_postdata( $post ); ?> 
								  
								  
								  <?php the_content(); ?>
								  
								<?php endforeach; wp_reset_postdata(); ?>	
								</div>
								
								
							
							
								
							
							</div>
							
					</div>
				</section>
				
				
				<section class="home-spending" id="spending">
					<div id="inner-content" class="wrap cf">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'spending' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							
							
							  setup_postdata( $post ); ?> 
							  <div class="spending-text">
							  <?php the_content(); ?>
							  </div>
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
							
						
					<div class="ct-chart ct-octave" id="chart1">
						<span class="value">11 Trillion</span>
						
					</div>
					
					<script>
						// Our labels and three data series
					var data = {
					  labels: ['2015', '2016', '2017', '2018', '2019', '2020'],
					  series: [
					    [1, 1.4, 2.3, 3.8, 6.8, 11]
					  ]
					};
					
					// We are setting a few options for our chart and override the defaults
					var options = {
					  // Don't draw the line chart points
					  showPoint: true,
					  // Disable line smoothing
					  lineSmooth: true,
					  showArea: true,
					  fullWidth: true,
					  chartPadding: {
					    left: 30,
					    right:20
					  },
					  // X-Axis specific configuration
					  axisX: {
					    // We can disable the grid for this axis
					    showGrid: false,
					    // and also don't show the label
					    showLabel: true
					  },
					  // Y-Axis specific configuration
					  axisY: {
						 // We can disable the grid for this axis
					    showGrid: false,
					    // and also don't show the label
					    showLabel: false,
					    // Lets offset the chart a bit from the labels
					    offset:0,
					    // The label interpolation function enables you to modify the values
					    // used for the labels on each axis. Here we are converting the
					    // values into million pound.
					    labelInterpolationFnc: function(value) {
					      return '$' + value + 'm';
					    }
					  }
					};
					
					// All you need to do is pass your configuration as third parameter to the chart function
					var chart = new Chartist.Line('.ct-chart', data, options);
					
					/*chart.on('draw', function(data) {
					  if(data.type === 'line' || data.type === 'area') {
					    data.element.animate({
					      d: {
					        begin: 2000 * data.index,
					        dur: 2000,
					        from: data.path.clone().scale(1, 0).translate(0, data.chartRect.height()).stringify(),
					        to: data.path.clone().stringify(),
					        easing: Chartist.Svg.Easing.easeOutQuint
					      }
					    });
					  }
					});
					*/

					</script>

					</div>
				</section>


				<section class="home-5" id="mall">
					<div id="inner-content" class="wrap wrap-home-wide mall-content cf">
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'megax-mall' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$mgxdesc = get_post_meta($post->ID, 'wpcf-megax-description', true);
							$mgximg = get_post_meta($post->ID, 'wpcf-megax-image', true);
							$mgximgdesc = get_post_meta($post->ID, 'wpcf-megax-image-desc', true);
							  setup_postdata( $post ); ?> 
							   
							 
							   <div class="m-all t-1of2 d-1of2 mall-title cf home-title scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
							    <?php the_content(); ?> 
							   </div>
							    <div class="m-all t-1of2 d-1of2 mall-description last-col cf home-title scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
								<?php echo apply_filters('the_content',$mgxdesc); ?>
							    </div>
							    
							   
								  <div class="m-all t-all d-all cf">
									  
										 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
								 <video id="vidmall" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-mall.jpg" muted loop preload="auto">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-mall.mp4" type="video/mp4">
			</video>
										 </div>
								<div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="20">
								<address><?php echo apply_filters('the_content',$mgximgdesc); ?></address>
									    </div>
								  </div>
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</div>
					
					<div class="wrap wrap-home-wide mall-content cf">
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'megax-events' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$mgxdesc = get_post_meta($post->ID, 'wpcf-megax-description', true);
							$mgximg = get_post_meta($post->ID, 'wpcf-megax-image', true);
							$mgximgdesc = get_post_meta($post->ID, 'wpcf-megax-image-desc', true);
							  setup_postdata( $post ); ?> 
							   
						
							   <div class="m-all t-1of2 d-1of2 mall-title cf scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
							    <?php the_content(); ?> 
							   </div>
							    <div class="m-all t-1of2 d-1of2 mall-description last-col cf scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
								<?php echo apply_filters('the_content',$mgxdesc); ?>
							    </div>
							
							    
								<div class="m-all t-all d-all last-col cf">
									 
									   <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
										
					<video id="videvent" poster="<?php bloginfo( 'template_url' ); ?>/library/images/megax-event.jpg" muted loop preload="auto">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-event.mp4" type="video/mp4">
			</video>
									   </div>
									   
									    <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
								<address><?php echo apply_filters('the_content',$mgximgdesc); ?></address>
									    </div>
								  </div>
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</div>
					
				</section>
				
				
				
				<section class="home-6" id="brands">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="30">
						<h2>Brands & Merchandise</h2>
						</div>
							
							<div class="m-all t-2of7 d-2of7 cf">
								 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
										
								 <ul class="brandstats-list">
									 <div id="triggerstats"></div>
									 <li id="animatestats1">
									 	<h3>25,000</h3>
									 	<p>Brands</p>
									 </li>
									 <li id="animatestats2">
									 	<h3>5,000,000</h3>
									 	<p>Customers</p>
									 </li>
									 <li id="animatestats3">
									 	<h3>27</h3>
									 	<p>Countries</p>
									 </li>
								 </ul>
								 
								 </div>
							 </div>
							 
							 <div class="m-all t-5of7 d-5of7 last-col cf">
								 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="20">
										
										
									<div id="triggerhighlights"></div>
									<ul class="highlights-list" id="animatehighlights1">
								
									<?php
									
									$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'brands' );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$mbrand1 = get_post_meta($post->ID, 'wpcf-main-brand-1', true);
									$mbrand2 = get_post_meta($post->ID, 'wpcf-main-brand-2', true);
									$mbrand3 = get_post_meta($post->ID, 'wpcf-main-brand-3', true);
									$mbrand4 = get_post_meta($post->ID, 'wpcf-main-brand-4', true);
									$mbrand5 = get_post_meta($post->ID, 'wpcf-main-brand-5', true);
									$mbrand6 = get_post_meta($post->ID, 'wpcf-main-brand-6', true);
									$mbrand7 = get_post_meta($post->ID, 'wpcf-main-brand-7', true);
									$mbrand8 = get_post_meta($post->ID, 'wpcf-main-brand-8', true);
									$brands = get_post_meta($post->ID, 'wpcf-brands', true);
									  setup_postdata( $post ); ?> 
									   
									   
									
										<li><?php echo apply_filters('the_content',$mbrand1); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand2); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand3); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand4); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand5); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand6); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand7); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand8); ?></li>
									   
									   
									<?php
									endforeach; 
									wp_reset_postdata();
									?>	
									</ul>
									
									
									
									<div class="brands-list" id="animatehighlights2">
									
									<?php
									
									$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'brands' );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$brands = get_post_meta($post->ID, 'wpcf-brands', true);
									  setup_postdata( $post ); ?> 
									   
									   <?php echo apply_filters('the_content',$brands); ?>
									   
									   
									<?php
									endforeach; 
									wp_reset_postdata();
									?>	
									</div>
									
									
										
								 </div>
										
								 
							
							 </div>
							
							
					</div>
					
				</section>
				
				<section class="home-2">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.5"
									data-translatey="50">
						<h2>Awards & Accolades</h2>
						</div>
						
						<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.5"
									data-translatey="70">
					<ul class="home-blog-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'awards' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$award2010 = get_post_meta($post->ID, 'wpcf-awards-2010', true);
							$award2012 = get_post_meta($post->ID, 'wpcf-awards-2012', true);
							$award2013 = get_post_meta($post->ID, 'wpcf-awards-2013', true);
							$award2014 = get_post_meta($post->ID, 'wpcf-awards-2014', true);
							$award2015 = get_post_meta($post->ID, 'wpcf-awards-2015', true);
							$award2016 = get_post_meta($post->ID, 'wpcf-awards-2016', true);
							$award2017 = get_post_meta($post->ID, 'wpcf-awards-2017', true);
							  setup_postdata( $post ); ?> 
							  
							  
							
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2010); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2012); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2013); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2014); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2015); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2016); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2017); ?></span></div>
								</li>
								
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
						</div>
					
					
					</div>
				</section>		
				
				<section class="home-4" id="team">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.5"
									data-translatey="50">
						<h2>The Team</h2>
						</div>
						
						
						<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.7"
									data-translatey="30">
					<ul class="home-team-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'the-team' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$team1 = get_post_meta($post->ID, 'wpcf-team-member-1', true);
							$team2 = get_post_meta($post->ID, 'wpcf-team-member-2', true);
							$team3 = get_post_meta($post->ID, 'wpcf-team-member-3', true);
							$team4 = get_post_meta($post->ID, 'wpcf-team-member-4', true);
							$team5 = get_post_meta($post->ID, 'wpcf-team-member-5', true);
							$team6 = get_post_meta($post->ID, 'wpcf-team-member-6', true);
							$team7 = get_post_meta($post->ID, 'wpcf-team-member-7', true);
							$team8 = get_post_meta($post->ID, 'wpcf-team-member-8', true);
							$team9 = get_post_meta($post->ID, 'wpcf-team-member-9', true);
							$team10 = get_post_meta($post->ID, 'wpcf-team-member-10', true);
							  setup_postdata( $post ); ?> 
							  
							  
							<?php if(!empty($team1)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team1); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team2)) { ?>								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team2); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team3)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team3); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team4)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team4); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team5)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team5); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team6)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team6); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team7)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team7); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team8)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team8); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team9)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team9); ?></span></div>
								</li>
							<?php } ?>
							<?php if(!empty($team10)) { ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team10); ?></span></div>
								</li>
							<?php } ?>
							
								
								
								
								
								
								
								
								
								
								
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
						</div>
					
					
					<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.5"
									data-translatey="50">
					<h2>Advisors</h2>
					</div>
					
					
					<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.7"
									data-translatey="30">
										
					<ul class="home-advisors-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'advisors' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$adv1 = get_post_meta($post->ID, 'wpcf-advisor-1', true);
							$adv2 = get_post_meta($post->ID, 'wpcf-advisor-2', true);
							$adv3 = get_post_meta($post->ID, 'wpcf-advisor-3', true);
							$adv4 = get_post_meta($post->ID, 'wpcf-advisor-4', true);
							$adv5 = get_post_meta($post->ID, 'wpcf-advisor-5', true);
							$adv6 = get_post_meta($post->ID, 'wpcf-advisor-6', true);
							$adv7 = get_post_meta($post->ID, 'wpcf-advisor-7', true);
							$adv8 = get_post_meta($post->ID, 'wpcf-advisor-8', true);
							  setup_postdata( $post ); ?> 
							  
							  
							<?php if(!empty($adv1)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv1); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv2)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv2); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv3)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv3); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv4)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv4); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv5)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv5); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv6)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv6); ?></span></div>
								</li>
								
							<?php } ?>
							
							<?php if(!empty($adv7)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv7); ?></span></div>
								</li>
								
							<?php } ?>
							<?php if(!empty($adv8)){ ?>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv8); ?></span></div>
								</li>
								
							<?php } ?>
							
							
								
							
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
					</div>
					
					
					</div>
				</section>
				
					
				</div>



	
		<script type="text/javascript">
  var bg = jQuery(".home-top");
  
jQuery(window).resize("resizeBackground");
function resizeBackground() {
    bg.height(jQuery(window).height());
}
resizeBackground();





$(".play").click(function(){
    $('.home-top').addClass('playing');
    $('.home-top').removeClass('collapsed');
    $('.video-overlay').addClass('playing');
 
});

$(".closevideo").click(function(){
    $('.home-top').removeClass('playing');
    $('.home-top').addClass('collapsed');
    $('.video-overlay').removeClass('playing');
 
});




function numberWithCommas(number) {
    var parts = number.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}


$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
            var num = $(this).text();
		    var commaNum = numberWithCommas(num);
		    $(this).text(commaNum);
		 }
    });
});

$(".countmilestone").each(function() {
    var num = $(this).text();
    var commaNum = numberWithCommas(num);
    $(this).text(commaNum);
  });


var percent = <?php echo $salevalue; ?>;
var percentage = "<?php echo $salepercent; ?>";

if (percent <= 0.3) {
	$(".progress").animate({
    width: percentage,
    opacity: 1
	});
	
	$(".actuals").animate({
	    opacity: 1,
	    
	});
	$(".actuals").addClass('left');
	
} else {
	
	$(".progress").animate({
    width: percentage,
    opacity: 1
	});
	
	$(".actuals").animate({
	    marginLeft: percentage,
	    opacity: 1
	});

}





// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween4 = TweenMax.to("#animatelist4", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween5 = TweenMax.to("#animatelist5", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween6 = TweenMax.to("#animatestats1", 1, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween7 = TweenMax.to("#animatestats2", 1, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween8 = TweenMax.to("#animatestats3", 1, {className: "+=isvisible", delay: 0.8, ease: Expo.easeOut});
	var tween9 = TweenMax.to("#animatehighlights1", 1, {className: "+=isvisible", delay: 0.5, ease: Expo.easeOut});
	var tween10 = TweenMax.to("#animatehighlights2", 1, {className: "+=isvisible", delay: 1, ease: Expo.easeOut});
	
	var vidF1 = document.getElementById('vidfeature1');
	var $vf1 = $('#vidfeature1');
	var vidF2 = document.getElementById('vidfeature2');
	var $vf2 = $('#vidfeature2');
	var vidF3 = document.getElementById('vidfeature3');
	var $vf3 = $('#vidfeature3');
	
	var mallVid = document.getElementById('vidmall');
	var $mv = $('#vidmall');
	var eventVid = document.getElementById('videvent');
	var $ev = $('#videvent');
	
	var heroBg = document.getElementById('herobg');
	var $hb = $('#herobg');
	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
			var scene5 = new ScrollMagic.Scene({triggerElement: "#vidmall", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$mv.hasClass('hasplayed')){
							 mallVid.play();
						} else {
							
						}
						
					})
			var scene6 = new ScrollMagic.Scene({triggerElement: "#videvent", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$ev.hasClass('hasplayed')){
							 eventVid.play();
							 
						} else {
							
						}
						
					})
			var scene13 = new ScrollMagic.Scene({triggerElement: "#vidfeature1", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$vf1.hasClass('hasplayed')){
							 vidF1.play();
							 $vf1.addClass('hasplayed');
						} else {
							
						}
						
					})
			var scene14 = new ScrollMagic.Scene({triggerElement: "#vidfeature2", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$vf2.hasClass('hasplayed')){
							 vidF2.play();
							 $vf2.addClass('hasplayed');
						} else {
							
						}
						
					})
			var scene15 = new ScrollMagic.Scene({triggerElement: "#vidfeature3", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$vf3.hasClass('hasplayed')){
							 vidF3.play();
							 $vf3.addClass('hasplayed');
						} else {
							
						}
						
					})		
					
					
			var scene12 = new ScrollMagic.Scene({triggerElement: "#herobg", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
							 heroBg.play();
					})
					
			var scene7 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);	
			var scene8 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);	
			var scene9 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween8)
					.addTo(controller);	
				
			var scene10 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween9)
					.addTo(controller);	
					
			var scene11 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween10)
					.addTo(controller);	


	</script>

									

<?php get_footer(); ?>
