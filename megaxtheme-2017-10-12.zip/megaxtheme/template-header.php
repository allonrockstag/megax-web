
<header class="header cd-header cd-header-default is-visible is-fixed" role="banner" itemscope itemtype="http://schema.org/WPHeader">


				<div id="inner-header" class="inner-header-appear">
				
					<?php // to use a image just replace the bloginfo('name') with your img src and remove the surrounding <p> ?>
					
					<div class="header-top">
					<p id="logo"><a href="<?php echo home_url(); ?>" rel="nofollow">
						<img src="<?php bloginfo( 'template_url' ); ?>/library/images/megax-logo.png" /></a></p>


					<?php // if you'd like to use the site description you can un-comment it below ?>
					<?php // bloginfo('description'); ?>

					
				
					
					
					
						<a id="menubutton" class="cd-primary-nav-trigger" href="#0">
						<!--<span class="cd-menu-text cd-menu-text">Menu</span>-->
						<span class="cd-menu-icon cd-menu-icon"></span>
					</a> <!-- cd-primary-nav-trigger -->
					
					
					
					<!--<button id="searchtrigger" class="md-trigger" data-modal="modal-7">
						</button>-->
					
					
						<nav class="nav nav-desktop-2" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
						
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'TopNav' ,  // nav name
    					         'menu_class' => 'nav top-nav cf',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>

					</nav>
					
					<div class="nav-2">
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'TopNav2' ,  // nav name
    					         'menu_class' => 'nav cf',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>
					</div>
						
						
					</div>
					
				</div>
				
					
			</header>
			
			<nav class="nav nav-mobile" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
					
				
						
					<ul class="cd-primary-nav">
						<div class="cd-primary-nav-header">
							<span>Navigate</span>
						<a id="menubutton" class="cd-primary-nav-trigger menubutton-trans" href="#0">
						<span class="cd-menu-icon cd-menu-icon"></span>
					</a> <!-- cd-primary-nav-trigger -->
						</div>
						
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'MobileNav' ,  // nav name
    					         'menu_class' => 'mobile-nav-2',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'MobileNav2' ,  // nav name
    					         'menu_class' => 'mobile-nav-2',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>
					
						
					</ul>
					
					</nav>