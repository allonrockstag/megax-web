
	<?php 
	$design = get_post_meta($post->ID, 'wpcf-article-design', true);  
							$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
							$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
							$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
							$post_type_name = get_post_type( $post->ID );
							$post_type = get_post_type_object( get_post_type($post) );
							$embed_code = wp_oembed_get($vidyoutube);
							$embed_code2 = wp_oembed_get($vidvimeo);
	?>
		  
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article" itemscope itemprop="blogPost" itemtype="http://schema.org/BlogPosting">
			  
			  
				<div class="m-all t-3of4 d-3of4 last-col cf post-article-normal">
					
					<div class="m-all t-all d-all cf post-header post-header-video">
                <header class="article-header entry-header">
					

                </header> <?php // end article header ?>
                
					</div>
				
				
				<div class="m-all t-all d-all cf post-article">
					
                <section class="entry-content cf" itemprop="articleBody">
	                <?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>

	                <?php if(has_post_thumbnail()) { ?>
	                
	                
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 

		                $featuredImageAlt = get_post_meta( get_post_thumbnail_id($post->ID) );
		                $imageAlt = $featuredImageAlt['_wp_attachment_image_alt']['0']; // Display Alt text
		                
	                ?>
				                  <!-- <img class="article-feature-img" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">-->
				      <?php } ?>
				      
				      
				      <?php if($design == '3'){ ?>
			            <?php if(has_post_thumbnail()) { ?>
		      
						    <img class="article-feature-img-mobile" src="<?php echo $featuredImage; ?>" alt="<?php echo $imageAlt; ?>">
						<?php } ?>
					<?php } ?>
		            
	               
                  <?php
                    // the content (pretty self explanatory huh)
                    the_content();

                    /*
                     * Link Pages is used in case you have posts that are set to break into
                     * multiple pages. You can remove this if you don't plan on doing that.
                     *
                     * Also, breaking content up into multiple pages is a horrible experience,
                     * so don't do it. While there are SOME edge cases where this is useful, it's
                     * mostly used for people to get more ad views. It's up to you but if you want
                     * to do it, you're wrong and I hate you. (Ok, I still love you but just not as much)
                     *
                     * http://gizmodo.com/5841121/google-wants-to-help-you-avoid-stupid-annoying-multiple-page-articles
                     *
                    */
                    wp_link_pages( array(
                      'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
                      'after'       => '</div>',
                      'link_before' => '<span>',
                      'link_after'  => '</span>',
                    ) );
                  ?>
                </section> <?php // end article section ?>

                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
                  	
        <div id="fbcomments"><div id="fb-root"></div>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
<fb:comments href="<?php the_permalink();?>" data-width="100%" data-numposts="5" data-colorscheme="light" ></fb:comments></div>

                </footer> <?php // end article footer ?>

               
                
                
				</div>
                 
                 
                 </div>
                 
                 


              </article> <?php // end article ?>

              
			
			 
			 
		 	