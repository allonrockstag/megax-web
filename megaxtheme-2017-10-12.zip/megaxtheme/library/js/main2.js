jQuery(document).ready(function($){
	//if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
	var MQL = 768;
	$('.cd-header').removeClass('cd-header-mini');
	//primary navigation slide-in effect
	if($(window).width() > MQL) {
		var headerHeight = $('.cd-header').height();
		$('.cd-header').removeClass('cd-header-mini');
		$(window).on('scroll',
		{
	        previousTop: 0
	        
	    }, 
	    function () {
		    var currentTop = $(window).scrollTop();
		    //check if user is scrolling up
		    
		    if (currentTop < this.previousTop ) {
		    	//if scrolling up...
		    	if (currentTop > 500 && $('.cd-header').hasClass('is-fixed')) {
		    		$('.cd-header').addClass('is-visible');
		    		
		    	} else {
		    		$('.cd-header').removeClass('is-visible is-fixed');
		    		$('.cd-menu-text').addClass('cd-menu-text-white');
		    		$('.cd-logo2').removeClass('cd-menu-remove');
		    		$('.cd-primary-nav-trigger').removeClass('cd-menu-remove');
		    		$('.cd-text-center').addClass('cd-menu-remove');
		    		$('.readnext').addClass('cd-menu-remove');
		    		$('.readprev').addClass('cd-menu-remove');
		    		$('.cd-header').removeClass('cd-header-mini');
		    	}
		    } else {
		    	//if scrolling down...
		    	$('.cd-header').removeClass('is-visible');
		    	
		    	if( currentTop > 500) {
		    	$('.cd-header').addClass('is-fixed is-visible');
		    	$('.cd-primary-nav-trigger').addClass('cd-menu-remove');
		    	$('.cd-logo2').addClass('cd-menu-remove');
		    	$('.cd-text-center').removeClass('cd-menu-remove');
		    	$('.readnext').removeClass('cd-menu-remove');
		    	$('.readprev').removeClass('cd-menu-remove');
		    	$('.cd-header').addClass('cd-header-mini');
		    	}
		    }
		    this.previousTop = currentTop;
		});
	}

	//open/close primary navigation
	$('.cd-primary-nav-trigger').on('click', function(){
		$('.cd-menu-icon').toggleClass('is-clicked'); 
		$('.cd-header').toggleClass('menu-is-open');
		
		//in firefox transitions break when parent overflow is changed, so we need to wait for the end of the trasition to give the body an overflow hidden
		if( $('.cd-primary-nav').hasClass('is-visible') ) {
			$('.cd-primary-nav').removeClass('is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',function(){
				$('body').removeClass('overflow-hidden');
			});
		} else {
			$('.cd-primary-nav').addClass('is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',function(){
				$('body').addClass('overflow-hidden');
			});	
		}
	});
});