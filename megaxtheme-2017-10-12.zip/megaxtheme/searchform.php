

<form role="search" method="get" id="searchform2" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput2" class="sb-search-input" placeholder="Search.." type="text" value="" name="s" id="s">
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>