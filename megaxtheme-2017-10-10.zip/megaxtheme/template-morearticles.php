<section class="article-morearticles">
					<div class="wrap cf">
						<div class="m-all t-all d-all cf">
							<div class="block-sponsored"></div>
						</div>
					
						<div class="m-all t-all d-all cf">
								<div class="block-more-posts">
									<?php 
									if( get_post_type() == 'post' ) { ?>
									    <h2>More News Like This</h2>
									<?php } else if ( get_post_type() == 'video' ) {?>	
										 <h2>More Videos Like This</h2>
									<?php } else {?>	
										<h2>More Like This</h2>
									<?php } ?>
									
									
									
									<ul class="more-posts-list">
										
										
										<?php $posttype = get_post_type();
											$countpost = 0; ?>
										<?php 
									if( $posttype == 'post' ) { ?>
									    <?php  $loop = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?> 
									<?php } ?>
									
									<?php if ( $posttype == 'fashion-post' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post'), 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?> 
									
									<?php if ( $posttype == 'beauty-post' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post'), 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?>
									<?php if ( $posttype == 'video' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => 'video', 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?>
									
									<?php if ( $posttype == 'art' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => 'art', 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?>
									
									<?php if ( $posttype !== 'post' && $posttype !== 'fashion-post' && $posttype !== 'beauty-post' && $posttype !== 'video' && $posttype !== 'art') { ?>
										<?php  $loop = new WP_Query( array( 'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post'), 'posts_per_page' => 5, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
										
									<?php } ?>
					<?php			
						if ( $loop->have_posts() ) :
				        while ( $loop->have_posts() ) : $loop->the_post();
				        $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
				        $design = get_post_meta($post->ID, 'wpcf-article-design', true); 
				        $post_type_name = get_post_type( $post->ID );
						$post_type = get_post_type_object( get_post_type($post) );
				        $countpost++; ?>
				            
				            
						 	  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 || $post_type_name == 'video') { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 || $post_type_name == 'video') { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div>	

				            <?php } ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
																
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
							</article>
							
							</div></a>
							
							
										  </li>	
										  
														            
				        <?php endwhile; ?>
				       
				  <?php  endif;
					  $countpost = 0;
				    wp_reset_postdata();
				?>

									</ul>
								</div>
						</div>
						<div class="m-all t-1of4 d-1of4 cf last-col">
							<span class="spacer">&nbsp;</span>
						</div>
					</div>
				</section>