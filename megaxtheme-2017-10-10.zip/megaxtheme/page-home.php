<?php
/*
 Template Name: Home
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<?php 	$f1 = get_post_meta($post->ID, 'wpcf-feature-1', true);
		$f2 = get_post_meta($post->ID, 'wpcf-feature-2', true);
		$f3 = get_post_meta($post->ID, 'wpcf-feature-3', true);
		$sf1 = get_post_meta($post->ID, 'wpcf-sub-feature-1', true);
		$sf2 = get_post_meta($post->ID, 'wpcf-sub-feature-2', true);
		$sf3 = get_post_meta($post->ID, 'wpcf-sub-feature-3', true);
?>


	<?php get_header(); ?>


 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
	?>
					
					
		
				<div id="content" class="nopadding">
				<section class="home-top">
					<div class="home-top-container scrollme animateme"
						      data-when="span"
						      data-from="0"
						      data-to="1"
						      data-easing="linear"
						      data-rotatey="0"
						      data-translatey="200">
					
					
					
					</div>
				</section>
				
				<section class="home-1">
					
				
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-1of2 d-1of2 cf">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home-title scrollme animateme"
						data-when="enter"
					    data-from="0.5"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="50">
							
				<h1>MegaX</h1>
				</div>
				
				
				<div class="home-1-content scrollme animateme"
						data-when="enter"
					    data-from="0.5"
					    data-to="0"
					    data-easing="linear"
						data-crop="true"
						data-translatey="70"
						>
						<?php the_content(); ?>
					</div>
				
				
				

			<?php endwhile; ?>
				
			<?php else : ?>

			<?php endif; ?>
			
						</div>
						
						
						<div class="m-all t-1of2 d-1of2 last-col cf">
							<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.5"
								    data-to="0.0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
							<div class="sale-box">
								
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$saletype = get_post_meta($post->ID, 'wpcf-sale-type', true);
							$saledeadline = get_post_meta($post->ID, 'wpcf-sale-deadline', true);
							$salemilestone = get_post_meta($post->ID, 'wpcf-sale-milestone', true);
							$saleprogress = get_post_meta($post->ID, 'wpcf-sale-progress', true);
							$salebonus = get_post_meta($post->ID, 'wpcf-current-bonus', true);
							$salecomm = get_post_meta($post->ID, 'wpcf-min-commitment', true);
							$salegas = get_post_meta($post->ID, 'wpcf-gas-limit', true);
							$bonusexp = get_post_meta($post->ID, 'wpcf-bonus-expiry', true);
							$salecta = get_post_meta($post->ID, 'wpcf-sale-cta', true);
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							
							  setup_postdata( $post ); ?> 
							  
							  <h2 class="live-alert">Token Sale is <strong>Live</strong></h2>
								<h3>Ends In <span id="clock"></span></h3> 
									
									<script type="text/javascript">
									  // 15 days from now!
									  $('#clock').countdown('2017/11/17 17:00:00', function(event) {
									    $(this).html(event.strftime('%DD %HH %MM %SS'));
									  });
									</script>
								<hr>
								
								<div class="sale-bar-container">
									
									
									
									<div id="progressbar">
										<div class="tokensale">
										<h3>Token Sale Progress</h3>
										</div>
										<div class="milestone">
											<h4>Milestone</h4>
											<p><span class="countmilestone">100000</span> ETH</p>
										</div>
									
										<div class="progressbg"><span class="progress"></span></div>
										
										<div class="actuals">
											<div class="arrow-up"></div>
											<p><span class="count">50000</span> ETH</p>
											<h4>Contributed</h4>
										</div>
									</div>
									
								</div>
							
							<div class="sale-box-field sale-box-field-first">
								<label>Current Bonus</label>
								 <?php echo apply_filters('the_content',$salebonus); ?>
							</div>
							
							<div class="sale-box-field">
								<label>Bonus Expiring In</label>
								 <p id="clock2"></p>
								 <script type="text/javascript">
									  // 15 days from now!
									  $('#clock2').countdown('2017/11/17 17:00:00', function(event) {
									    $(this).html(event.strftime('%DD %H:%M:%S'));
									  });
									</script>
							</div>
							<div class="sale-box-field">
								<label>Min. Commitment</label>
								 <?php echo apply_filters('the_content',$salecomm); ?>
							</div>
							<div class="sale-box-field">
								<label>Gas Limit</label>
								 <?php echo apply_filters('the_content',$salegas); ?>
							</div>
							
							
							<div class="sale-box-field sale-box-cta sale-box-field-last">
								 <?php echo apply_filters('the_content',$salecta); ?>
								 
								 <button>Get MegaX Tokens</button>
							</div>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
							
								
							</div>
							
							</div>
							
							
							<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.2"
								    data-to="0.0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="40">
							<div class="sale-box sale-box-2">
									<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'sale-section' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$saletype = get_post_meta($post->ID, 'wpcf-sale-type', true);
							$saledeadline = get_post_meta($post->ID, 'wpcf-sale-deadline', true);
							$salemilestone = get_post_meta($post->ID, 'wpcf-sale-milestone', true);
							$saleprogress = get_post_meta($post->ID, 'wpcf-sale-progress', true);
							$salebonus = get_post_meta($post->ID, 'wpcf-sale-bonus', true);
							$salecomm = get_post_meta($post->ID, 'wpcf-sale-commitment', true);
							$salegas = get_post_meta($post->ID, 'wpcf-gas-limit', true);
							$bonusexp = get_post_meta($post->ID, 'wpcf-bonus-expiry', true);
							$salecta = get_post_meta($post->ID, 'wpcf-sale-cta', true);
							$notified = get_post_meta($post->ID, 'wpcf-get-notified', true);
							
							  setup_postdata( $post ); ?> 
							  
							  
							
								  <?php echo apply_filters('the_content',$notified); ?>
								 
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							</div>
							
							</div>
						</div>
					</div>
					
					
					
					<!--<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							<div id="triggerlist"></div>
						<ul class="home-svc-list">
							<li id="animatelist1"><?php echo apply_filters('the_content',$f1); ?></li>
							<li id="animatelist2"><?php echo apply_filters('the_content',$f2); ?></li>
							<li id="animatelist3"><?php echo apply_filters('the_content',$f3); ?></li>
							<li id="animatelist4"><?php echo apply_filters('the_content',$svc4); ?></li>
							<li id="animatelist5"><?php echo apply_filters('the_content',$svc5); ?></li>	
						</ul>
						</div>
					</div>-->
					
				</section>
				
				<section class="home-1a">
					<section class="home-feature">
						
							<div class="feature-video feature-video-1 scrollme animateme scrollmedesktop"
							      data-when="span"
							      data-from="0"
							      data-to="1"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="400"></div>
							
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist1"></div>
							<ul class="home-svc-list">
								<li id="animatelist1"><?php echo apply_filters('the_content',$f1); ?></li>
							</ul>
							</div>
						</div>
					</section>
					<section class="home-feature">
						
					<div class="feature-video feature-video-2 scrollme animateme"
							      data-when="span"
							      data-from="0"
							      data-to="0.6"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="500"></div>
						
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist2"></div>
							<ul class="home-svc-list">
								<li id="animatelist2"><?php echo apply_filters('the_content',$f2); ?></li>
							</ul>
							</div>
						</div>
					</section>
					<section class="home-feature">
						
					<div class="feature-video feature-video-3 scrollme animateme"
							      data-when="span"
							      data-from="0"
							      data-to="0.5"
							      data-easing="linear"
							      data-rotatey="0"
							      data-translatey="400"></div>
						
							<div id="inner-content" class="wrap wrap-home-wide cf">
							<div class="m-all t-all d-1of2 cf">
								<div id="triggerlist3"></div>
							<ul class="home-svc-list">
								<li id="animatelist3"><?php echo apply_filters('the_content',$f3); ?></li>
							</ul>
							</div>
						</div>
					</section>
					
					
					<section class="home-subfeature">
						<div id="inner-content" class="wrap cf">
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="subfeature-list">
								<div class="subfeature-img"></div>
								<?php echo apply_filters('the_content',$sf1); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="subfeature-list">
									<div class="subfeature-img"></div>
								<?php echo apply_filters('the_content',$sf2); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 last-col cf">
								<div class="subfeature-list">
									<div class="subfeature-img"></div>
								<?php echo apply_filters('the_content',$sf3); ?>
								</div>
							</div>
							
						</div>
					</section>
				</section>
					
					
						
						
				<section class="home-3">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="m-all t-all d-all cf">
							
							
								<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.3"
									data-translatey="30">
										
									<h2>Initial Token Sale</h2>
								</div>
									
										<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'token-sale' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$ts1 = get_post_meta($post->ID, 'wpcf-token-sale-1', true);
							$ts2 = get_post_meta($post->ID, 'wpcf-token-sale-2', true);
							$ts3 = get_post_meta($post->ID, 'wpcf-token-sale-3', true);
							
							  setup_postdata( $post ); ?> 
							  
							  
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									 
								<ul class="progress">	
								<li data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								
								
								<!--  Defining Angle Gradient Colors  -->
									<svg width="0" height="0">
									<defs>
									<linearGradient id="cl1" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="1" y2="1">
									    <stop stop-color="#ce1f78"/>
									    <stop offset="100%" stop-color="#a63895"/>
									</linearGradient>
									<linearGradient id="cl2" gradientUnits="objectBoundingBox" x1="0" y1="0" x2="0" y2="1">
									    <stop stop-color="#a63895"/>
									    <stop offset="100%" stop-color="#3e79e0"/>
									</linearGradient>
									<linearGradient id="cl3" gradientUnits="objectBoundingBox" x1="1" y1="0" x2="0" y2="1">
									    <stop stop-color="#3e79e0"/>
									    <stop offset="100%" stop-color="#506dd3"/>
									</linearGradient>
									<linearGradient id="cl4" gradientUnits="objectBoundingBox" x1="1" y1="1" x2="0" y2="0">
									    <stop stop-color="#506dd3"/>
									    <stop offset="100%" stop-color="#b42f8b"/>
									</linearGradient>
									<linearGradient id="cl5" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="0" y2="0">
									    <stop stop-color="#b42f8b"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									<linearGradient id="cl6" gradientUnits="objectBoundingBox" x1="0" y1="1" x2="1" y2="0">
									    <stop stop-color="#d41b74"/>
									    <stop offset="100%" stop-color="#d41b74"/>
									</linearGradient>
									</defs>
									</svg>
									
									
								  <?php echo apply_filters('the_content',$ts1); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="second" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								 <?php echo apply_filters('the_content',$ts2); ?>
								</div>
							</div>
							<div class="m-all t-1of3 d-1of3 last-col cf">
								<div class="tokensale-list">
									<ul class="progress">	
								<li class="third" data-percent="100%">
							        <svg viewBox="-10 -10 220 220">
							        <g fill="none" stroke-width="7" transform="translate(100,100)">
							        <path d="M 0,-100 A 100,100 0 0,1 86.6,-50" stroke="url(#cl1)"/>
							        <path d="M 86.6,-50 A 100,100 0 0,1 86.6,50" stroke="url(#cl2)"/>
							        <path d="M 86.6,50 A 100,100 0 0,1 0,100" stroke="url(#cl3)"/>
							        <path d="M 0,100 A 100,100 0 0,1 -86.6,50" stroke="url(#cl4)"/>
							        <path d="M -86.6,50 A 100,100 0 0,1 -86.6,-50" stroke="url(#cl5)"/>
							        <path d="M -86.6,-50 A 100,100 0 0,1 0,-100" stroke="url(#cl6)"/>
							        </g>
							        </svg>
							        <svg viewBox="-10 -10 220 220">
							        <path d="M200,100 C200,44.771525 155.228475,0 100,0 C44.771525,0 0,44.771525 0,100 C0,155.228475 44.771525,200 100,200 C155.228475,200 200,155.228475 200,100 Z" stroke-dashoffset="629"></path>
							        </svg>
							    </li>
								</ul>
								<?php echo apply_filters('the_content',$ts3); ?>
								</div>
							</div>
							
							<div class="m-all t-all d-all cf">
								 <button class="gettoken">Get MegaX Tokens</button>
							</div>
								 
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
							
						
							<div class="m-all t-all d-all cf roadmap-container">
								<div class="home-title scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.3"
							data-translatey="30">
								<h2>12-Month Product Roadmap</h2>
								</div>
								
								
								asdasd
							</div>
							
					</div>
				</section>
				
				<section class="home-5">
					<div id="inner-content" class="wrap wrap-home-wide mall-content cf">
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'megax-mall' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$mgxdesc = get_post_meta($post->ID, 'wpcf-megax-description', true);
							$mgximg = get_post_meta($post->ID, 'wpcf-megax-image', true);
							$mgximgdesc = get_post_meta($post->ID, 'wpcf-megax-image-desc', true);
							  setup_postdata( $post ); ?> 
							   
							   <div class="home-title scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
							   <div class="m-all t-1of2 d-1of2 mall-title cf">
							    <?php the_content(); ?> 
							   </div>
							    <div class="m-all t-1of2 d-1of2 mall-description last-col cf">
								<?php echo apply_filters('the_content',$mgxdesc); ?>
							    </div>
							    
							   </div>
							   
								  <div class="m-all t-all d-all cf">
									  
										 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
								 <video id="vidmall" poster="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.jpg" muted preload="auto" id="bgvid">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.mp4" type="video/mp4">
			</video>
										 </div>
								<div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="20">
								<address><?php echo apply_filters('the_content',$mgximgdesc); ?></address>
									    </div>
								  </div>
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</div>
					
					<div id="inner-content" class="wrap wrap-home-wide mall-content cf">
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'megax-events' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$mgxdesc = get_post_meta($post->ID, 'wpcf-megax-description', true);
							$mgximg = get_post_meta($post->ID, 'wpcf-megax-image', true);
							$mgximgdesc = get_post_meta($post->ID, 'wpcf-megax-image-desc', true);
							  setup_postdata( $post ); ?> 
							   
							  <div class="home-title scrollme animateme"
							data-when="enter"
						    data-from="0.8"
						    data-to="0"
						    data-easing="linear"
							data-crop="true"
							data-opacity="0.5"
							data-translatey="80">
							   <div class="m-all t-1of2 d-1of2 mall-title cf">
							    <?php the_content(); ?> 
							   </div>
							    <div class="m-all t-1of2 d-1of2 mall-description last-col cf">
								<?php echo apply_filters('the_content',$mgxdesc); ?>
							    </div>
							    </div>
							    
								<div class="m-all t-all d-all last-col cf">
									 
									   <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
										
									  <video id="videvent" poster="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.jpg" muted preload="auto" id="bgvid">
			    <source src="<?php bloginfo( 'template_url' ); ?>/library/images/airpod-large.mp4" type="video/mp4">
			</video>
									   </div>
									   
									    <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
								<address><?php echo apply_filters('the_content',$mgximgdesc); ?></address>
									    </div>
								  </div>
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</div>
					
				</section>
				
				<section class="home-6">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="30">
						<h2>Brands & Merchandise</h2>
						</div>
							
							<div class="m-all t-2of7 d-2of7 cf">
								 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="50">
										
								 <ul class="brandstats-list">
									 <div id="triggerstats"></div>
									 <li id="animatestats1">
									 	<h3>25,000</h3>
									 	<p>Brands</p>
									 </li>
									 <li id="animatestats2">
									 	<h3>5,000,000</h3>
									 	<p>Customers</p>
									 </li>
									 <li id="animatestats3">
									 	<h3>27</h3>
									 	<p>Countries</p>
									 </li>
								 </ul>
								 
								 </div>
							 </div>
							 
							 <div class="m-all t-5of7 d-5of7 last-col cf">
								 <div class="home-1-content scrollme animateme"
									data-when="span"
								    data-from="0.8"
								    data-to="0"
								    data-easing="linear"
									data-crop="true"
									data-translatey="20">
										
										
									<div id="triggerhighlights"></div>
									<ul class="highlights-list" id="animatehighlights1">
								
									<?php
									
									$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'brands' );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$mbrand1 = get_post_meta($post->ID, 'wpcf-main-brand-1', true);
									$mbrand2 = get_post_meta($post->ID, 'wpcf-main-brand-2', true);
									$mbrand3 = get_post_meta($post->ID, 'wpcf-main-brand-3', true);
									$mbrand4 = get_post_meta($post->ID, 'wpcf-main-brand-4', true);
									$mbrand5 = get_post_meta($post->ID, 'wpcf-main-brand-5', true);
									$mbrand6 = get_post_meta($post->ID, 'wpcf-main-brand-6', true);
									$mbrand7 = get_post_meta($post->ID, 'wpcf-main-brand-7', true);
									$mbrand8 = get_post_meta($post->ID, 'wpcf-main-brand-8', true);
									$brands = get_post_meta($post->ID, 'wpcf-brands', true);
									  setup_postdata( $post ); ?> 
									   
									   
									
										<li><?php echo apply_filters('the_content',$mbrand1); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand2); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand3); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand4); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand5); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand6); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand7); ?></li>
										<li><?php echo apply_filters('the_content',$mbrand8); ?></li>
									   
									   
									<?php
									endforeach; 
									wp_reset_postdata();
									?>	
									</ul>
									
									
									
									<div class="brands-list" id="animatehighlights2">
									
									<?php
									
									$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'brands' );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$brands = get_post_meta($post->ID, 'wpcf-brands', true);
									  setup_postdata( $post ); ?> 
									   
									   <?php echo apply_filters('the_content',$brands); ?>
									   
									   
									<?php
									endforeach; 
									wp_reset_postdata();
									?>	
									</div>
									
									
										
								 </div>
										
								 
							
							 </div>
							
							
					</div>
					
				</section>
				
				<section class="home-2">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.3"
									data-translatey="50">
						<h2>Awards & Accolades</h2>
						</div>
						
						<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.3"
									data-translatey="70">
					<ul class="home-blog-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'awards' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$award2010 = get_post_meta($post->ID, 'wpcf-awards-2010', true);
							$award2012 = get_post_meta($post->ID, 'wpcf-awards-2012', true);
							$award2013 = get_post_meta($post->ID, 'wpcf-awards-2013', true);
							$award2014 = get_post_meta($post->ID, 'wpcf-awards-2014', true);
							$award2015 = get_post_meta($post->ID, 'wpcf-awards-2015', true);
							$award2016 = get_post_meta($post->ID, 'wpcf-awards-2016', true);
							$award2017 = get_post_meta($post->ID, 'wpcf-awards-2017', true);
							  setup_postdata( $post ); ?> 
							  
							  
							
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2010); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2012); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2013); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2014); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2015); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2016); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$award2017); ?></span></div>
								</li>
								
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
						</div>
					
					
					</div>
				</section>		
				
				<section class="home-4">
					<div id="inner-content" class="wrap wrap-home-wide cf">
						<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.3"
									data-translatey="50">
						<h2>The Team</h2>
						</div>
						
						
						<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.3"
									data-translatey="70">
					<ul class="home-team-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'the-team' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$team1 = get_post_meta($post->ID, 'wpcf-team-member-1', true);
							$team2 = get_post_meta($post->ID, 'wpcf-team-member-2', true);
							$team3 = get_post_meta($post->ID, 'wpcf-team-member-3', true);
							$team4 = get_post_meta($post->ID, 'wpcf-team-member-4', true);
							$team5 = get_post_meta($post->ID, 'wpcf-team-member-5', true);
							$team6 = get_post_meta($post->ID, 'wpcf-team-member-6', true);
							$team7 = get_post_meta($post->ID, 'wpcf-team-member-7', true);
							$team8 = get_post_meta($post->ID, 'wpcf-team-member-8', true);
							$team9 = get_post_meta($post->ID, 'wpcf-team-member-9', true);
							$team10 = get_post_meta($post->ID, 'wpcf-team-member-10', true);
							  setup_postdata( $post ); ?> 
							  
							  
							
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team1); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team2); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team3); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team4); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team5); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team6); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team7); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team8); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$team9); ?></span></div>
								</li>
								 
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
						</div>
					
					
					<div class="home-title scrollme animateme"
									data-when="enter"
								    data-from="0.8"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
									data-opacity="0.3"
									data-translatey="50">
					<h2>Advisors</h2>
					</div>
					
					
					<div class="home-1-content scrollme animateme"
									data-when="enter"
								    data-from="0.7"
								    data-to="0.3"
								    data-easing="linear"
									data-crop="true"
										data-opacity="0.3"
									data-translatey="70">
										
					<ul class="home-advisors-list">
						
							<?php
							
							$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'advisors' );
							$postslist = get_posts( $args );
							foreach ( $postslist as $post ) :
							$adv1 = get_post_meta($post->ID, 'wpcf-advisor-1', true);
							$adv2 = get_post_meta($post->ID, 'wpcf-advisor-2', true);
							$adv3 = get_post_meta($post->ID, 'wpcf-advisor-3', true);
							$adv4 = get_post_meta($post->ID, 'wpcf-advisor-4', true);
							$adv5 = get_post_meta($post->ID, 'wpcf-advisor-5', true);
							$adv6 = get_post_meta($post->ID, 'wpcf-advisor-6', true);
							$adv7 = get_post_meta($post->ID, 'wpcf-advisor-7', true);
							$adv8 = get_post_meta($post->ID, 'wpcf-advisor-8', true);
							  setup_postdata( $post ); ?> 
							  
							  
							
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv1); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv2); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv3); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv4); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv5); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv6); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv7); ?></span></div>
								</li>
								<li>
									<div class="list-item"><span><?php echo apply_filters('the_content',$adv8); ?></span></div>
								</li>
							
											
							<?php
							endforeach; 
							wp_reset_postdata();
							?>	
						
						
					</ul>
					</div>
					
					
					</div>
				</section>
				
					
				</div>

	
		<script type="text/javascript">
  var bg = jQuery(".home-top");
  
jQuery(window).resize("resizeBackground");
function resizeBackground() {
    bg.height(jQuery(window).height());
}
resizeBackground();

function numberWithCommas(number) {
    var parts = number.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}


$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
            var num = $(this).text();
		    var commaNum = numberWithCommas(num);
		    $(this).text(commaNum);
		 }
    });
});

$(".countmilestone").each(function() {
    var num = $(this).text();
    var commaNum = numberWithCommas(num);
    $(this).text(commaNum);
  });


$(".progress").animate({
    width: "50%",
    opacity: 1
});

$(".actuals").animate({
    marginLeft: "50%",
    opacity: 1
});



// init controller
	var controller = new ScrollMagic.Controller();


		
	var tween1 = TweenMax.to("#animatelist1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween2 = TweenMax.to("#animatelist2", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween3 = TweenMax.to("#animatelist3", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween4 = TweenMax.to("#animatelist4", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween5 = TweenMax.to("#animatelist5", 1.2, {className: "+=isvisible", delay: 0.4, ease: Expo.easeOut});
	var tween6 = TweenMax.to("#animatestats1", 1.2, {className: "+=isvisible", delay: 0, ease: Expo.easeOut});
	var tween7 = TweenMax.to("#animatestats2", 1.2, {className: "+=isvisible", delay: 0.5, ease: Expo.easeOut});
	var tween8 = TweenMax.to("#animatestats3", 1.2, {className: "+=isvisible", delay: 1, ease: Expo.easeOut});
	var tween9 = TweenMax.to("#animatehighlights1", 1.2, {className: "+=isvisible", delay: 1, ease: Expo.easeOut});
	var tween10 = TweenMax.to("#animatehighlights2", 1.2, {className: "+=isvisible", delay: 1.5, ease: Expo.easeOut});
	
	var mallVid = document.getElementById('vidmall');
	var $mv = $('#vidmall');
	var eventVid = document.getElementById('videvent');
	var $ev = $('#videvent');
	
	// build scene
				var scene1 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist1",
					reverse: false,
					duration: 0
					})
					.setTween(tween1)
					.addTo(controller);
					
				var scene2 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist2",
					reverse: false,
					duration: 0
					})
					.setTween(tween2)
					.addTo(controller);
					
				var scene3 = new ScrollMagic.Scene({
					triggerElement: "#triggerlist3",
					reverse: false,
					duration: 0
					})
					.setTween(tween3)
					.addTo(controller);	
					
				var scene4 = new ScrollMagic.Scene({triggerElement: "#triggervid1", duration: 800, offset: 400})
						.setPin("#pin1")
						.addTo(controller);
			
			var scene5 = new ScrollMagic.Scene({triggerElement: "#vidmall", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$mv.hasClass('hasplayed')){
							 mallVid.play();
							 $mv.addClass('hasplayed');
						} else {
							
						}
						
					})
			var scene6 = new ScrollMagic.Scene({triggerElement: "#videvent", duration: 0 })
					.addTo(controller)
										
					.on("enter", function () {
						if(!$ev.hasClass('hasplayed')){
							 eventVid.play();
							 $ev.addClass('hasplayed');
						} else {
							
						}
						
					})
					
			var scene7 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween6)
					.addTo(controller);	
			var scene8 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween7)
					.addTo(controller);	
			var scene9 = new ScrollMagic.Scene({
					triggerElement: "#triggerstats",
					reverse: false,
					duration: 0
					})
					.setTween(tween8)
					.addTo(controller);	
				
			var scene10 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween9)
					.addTo(controller);	
					
			var scene11 = new ScrollMagic.Scene({
					triggerElement: "#triggerhighlights",
					reverse: false,
					duration: 0
					})
					.setTween(tween10)
					.addTo(controller);	


	</script>

									

<?php get_footer(); ?>
